import React from 'react'
import MyStyles from './MyStyles.css'

function Stylesheets(props) {
    let Classname = props.primary ? 'primary' : ''
    return (
        <div>
            <h1 className={`${Classname} font-xl`}>Style Sheets</h1>
        </div>
    )
}

export default Stylesheets
