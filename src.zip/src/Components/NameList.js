import React from 'react'
import Person from './Person'

function NameList() {
      const names = ['Devang','Dev','nik','Devang']

    const persons = [{
        id: 1,
        name: 'Devang',
        age: 28,
        sklill: 'react'

    }, {
        id: 2,
        name: 'Dhara',
        age: 25,
        sklill: 'angualr'
    },
    {
        id: 3,
        name: 'nik',
        age: 22,
        sklill: 'nodejs'
    }
    ]
    const NameList = names.map((name,index) => <h2 key={index}>{index} {name}</h2>)
    return <div>{NameList}</div>

}

export default NameList
