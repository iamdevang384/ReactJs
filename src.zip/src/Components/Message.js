import React, { Component } from 'react'

class Message extends Component {
    constructor(props) {
        super()
        this.state = {
            Message: 'Welcome visitor'
        }
        console.log(this.state)
        console.log(props)
    }

    changeMessage() {
        this.setState({
            Message: 'Thank You for subscribing.'
        })
    }
    render() {
        return (
            <div>
                <h1>{this.state.Message}</h1>
                <button onClick={() => this.changeMessage()}>Subscribe</button>
            </div>
        )
    }
}

export default Message