import React from 'react'

function FunctionClick() {

    function functionClick(){
        console.log('button clicked')
    }

    return (
        <div>
            <button onClick = {functionClick}>Click</button>
        </div>
    )
}

export default FunctionClick
